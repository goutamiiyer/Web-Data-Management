
<html>
    <head>		
        <title>Class About Codeigniter Form Helper </title>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'>
    </head>
    <body> 
        <div class="main">
            <div id="content">
                <h2 id="form_head">Class About Codelgniter Form Helper Demo</h2><br/>
                <hr>
                <div id="form_input">
                    <?php
                    echo form_open('form_submit/data_submitted');
                    echo form_label('Student Name' . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;');
                    $data_name = array(
                        'name' => 'std_name',
                        'id' => 'std_name_id',
                        'class' => 'input_box',
                        'placeholder' => 'Please Enter Student Name'
                    );
                    echo form_input($data_name);
                    echo "<br>";
                    echo "<br>";
                    echo form_label('Student Email-ID'.'&nbsp;');
                    $data_email = array(
                        'type' => 'email',
                        'name' => 'std_email',
                        'id' => 'e_email_id',
                        'class' => 'input_box',
                        'placeholder' => 'Please Enter Email'
                    );
                    echo form_input($data_email);
                    echo "<br>";
                    echo "<br>";
                    echo form_label('Password' . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;');
                    $data_password = array(
                        'name' => 'password',
                        'id' => 'password_id',
                        'class' => 'input_box',
                        'placeholder' => 'Please Enter Password'
                    );
                    echo form_password($data_password);
                    echo "<br>";
                    echo "<br>";
                    echo form_label('Gender' . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;');
                    $data_gender = array(
                        'Male' => 'Male',
                        'Female' => 'Female'
                    );
                    echo form_dropdown('select', $data_gender, 'Male', 'class="dropdown_box"');
                    echo "<br>";
                    echo "<br>";
                    echo form_label('Marital status');
                    echo "<div id = \"radio_list\">";
                    $data_radio1 = array(
                        'name' => 'std_marital_status',
                        'value' => 'Unmarried',
                        'checked' => TRUE,
                    );
                    echo form_radio($data_radio1);
                    echo form_label('Unmarried');
                    $data_radio2 = array(
                        'name' => 'std_marital_status',
                        'value' => 'Married',
                    );
                    echo form_radio($data_radio2);
                    echo form_label('Married');
                    echo "</div>";
                    echo "<br>";
                    echo form_label('Qualification');
                    $data_checkbox1 = array(
                        'name' => 'qualification[]',
                        'value' => 'Graduation'
                    );
                    echo "<div id = \"checkbox_list\">";
                    echo "<br>";
                    echo form_checkbox($data_checkbox1);
                    echo form_label('Graduation');
                    $data_checkbox2 = array(
                        'name' => 'qualification[]',
                        'value' => 'Post Graduation'
                    );
                    echo "<br>";
                    echo form_checkbox($data_checkbox2);
                    echo form_label('Post-Graduation');
                    echo "<br>";
                    echo "</div>";
                    echo "<br>";
                    echo form_label('Address');
                    echo "<div class='textarea_input'>";
                    $data_textarea = array(
                        'name' => 'address',
                        'rows' => 5,
                        'cols' => 32
                    );
                    echo form_textarea($data_textarea);
                    echo "</div>";
                    echo "<br>";

                    echo form_label('Upload Image');
                    echo "<div class='upload'>";
                    $data_upload = array(
                        'type' => 'file',
                        'name' => 'file_upload',
                        'value' => 'upload resume'
                    );
                    echo form_upload($data_upload);
                    echo "</div>";
                    echo "<br>";
                  
                    ?>
                </div>
                <div id="form_button">
                    <?php echo form_reset('reset', 'Reset', "class='submit'"); ?>
                    <?php echo form_submit('submit', 'Submit', "class='submit'"); ?>
                </div>                   
                <?php echo form_close(); ?>
                <?php
                if (isset($std_name)) {
                    $checkbox_value = unserialize($std_qualification);
                    echo "<div id='content_result'>";
                    echo "<h3 id='result_id'>You have submitted these values</h3><br/><hr>";
                    echo "<div id='result_show'>";
                    echo "<label class='label_output'>Entered Student Name : </label>" . $std_name;
                    echo"<br/><br/>";
                    echo "<label class='label_output'>Entered Student Email&nbsp;&nbsp;: </label>" . $std_email;
                    echo"<br/><br/>";
                    echo "<label class='label_output'>Entered Password&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </label>" . $std_password;
                    echo"<br/><br/>";
                    echo "<label class='label_output'>Entered Gender&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: </label>" . $std_gender;
                    echo"<br/><br/>";
                    echo "<label class='label_output'>Entered Marital status&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </label>" . $std_marital_status;
                    echo"<br/><br/>";
                    echo "<label class='label_output'>Entered Qualification&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </label>";
                    echo "<ul class='qual_output'>";
                    if (isset($checkbox_value) && $checkbox_value != NULL) {
                        foreach ($checkbox_value as $value) {
                            echo "<li>" . $value . "</li>";
                        }
                    }
                    echo "</ul>";
                    echo"<br/><br/>";
                    echo "<label class='label_output'>Entered Address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </label><pre class='address_output'>".$std_address."</pre>";
                    echo "<label class='label_output'>Uploaded Image&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </label>".$std_upload_file;
                    echo "<div>";
                    echo "</div>";
                }
                ?>
            </div> 
        </div>
    </body>
</html>







