
        <?php $this->load->view('page_header'); ?>
        <?php $data['blog_text'] = "You are in CSS Tutorial Page"; ?>
        <?php $this->load->view('page_menu', $data); ?>
        <?php $this->load->view('page_footer'); ?>
