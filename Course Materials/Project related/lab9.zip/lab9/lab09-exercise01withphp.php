<?php 
$days=array("Monday", "Tuesday","Wednesday", "Thursday","Friday","Saturday","Sunday");
$highs=array(20,30,26,30,30,29,25);
$lows=array(10,11,15,18,20,13,11);
/* Outputs weather for one day
depending of the day
*/
functiion outputForecast($day,$high,$low){
  echo '<div class="panel <div class="panel panel-default">';
  echo '<div class="panel-heading">';
  echo '<h3 class="panel-title">Monday</h3>';
  echo '</div>';
  echo '<div class="panel-body">';
  echo '<table class="table table-hover"><tbody>';
  echo '<tr><td>High:</td><td>100&deg;??</td></tr>';
   echo '<tr><td>Low:</td><td>100&deg;??</td></tr>';
  echo  '</tbody>        </table>';
  echo '</div>';
 echo ' </div>';
}
?>
<html lang="en">
<head>

<!-- Latest compiled and minified Bootstrap Core CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<!-- Bootstrap theme -->
<link href="../../dist/css/bootstrap-theme.min.css" rel="stylesheet">

   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <title>Exercise 9-1 Weather Forecast</title>
</head>

<body>
<header>
</header>

 <div class="container theme-showcase" role="main">  
  <?php
   outputForecast($days[0],$highs[0],$lows[0]);
  ?>
 </div>
</body>
</html>