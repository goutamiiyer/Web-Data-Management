<?php 
// $highs=array("Monday" =>20, "Tuesday" =>30,"Wednesday" =>26, "Thursday" =>30,"Friday" =>30,"Saturday" =>30,"Sunday" =>30);
// $lows=array("Monday" =>10, "Tuesday" =>11,"Wednesday" =>15, "Thursday" =>18,"Friday" =>20,"Saturday" =>13,"Sunday" =>11);
// $highs=array(20,30,26,30,30,29,25); $lows=array(10,11,15,18,20,13,11);
// $players = array("Jhan Belig" => 189,"Yemenev Baltroy" => 367,"Ilroy Malvi" => 210,
// "James John" => 121,"Walton Ling" => 368,"Mitch Moore" => 382,"Urslaw Whig" =>422,
// "Leo M. Toalde" => 192,"Richard Bee" => 281,"Travis Wise" =>182);
function doPrint($value,$key){
  echo '<div class="panel <div class="panel panel-default">';
  // echo '<div class="panel-heading">'; echo '<h3 class="panel-title">'."Name  Score".'</h3>';
  echo '</div>';echo '<div class="panel-body">';
  echo '<table class="table table-hover"><tbody>';
   // echo '<tr><th>Name:</th><th>Score</td></tr>';
  echo '<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';
  echo  '</tbody</table>'; echo '</div>';echo ' </div>'; } ?>
html lang="en">
<head>

<!-- Latest compiled and minified Bootstrap Core CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<!-- Bootstrap theme -->
<link href="../../dist/css/bootstrap-theme.min.css" rel="stylesheet">

   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <title>Exercise 9-3 | Sorting arrays</title>
</head>

<body>
<header>
</header>

 <div class="container theme-showcase" role="main">  
      <div class="jumbotron">
        <h1>Division Leaderboard</h1>
	<p>Sports League</p>
      </div>

<?php

 $players = array("Jhan Belig" => 189,"Yemenev Baltroy" => 367,"Ilroy Malvi" => 210,
"James John" => 121,"Walton Ling" => 368,"Mitch Moore" => 382,"Urslaw Whig" =>422,
"Leo M. Toalde" => 192,"Richard Bee" => 281,"Travis Wise" =>182);
 echo '<table class="table table-hover"><tbody>';
   echo '<tr><th>Name:</th><th>Score</td></tr>';
   echo  '</tbody</table>'; echo '</div>';echo ' </div>'; 
array_walk($players,"doPrint");
?>
 </div>
</body>
</html>
