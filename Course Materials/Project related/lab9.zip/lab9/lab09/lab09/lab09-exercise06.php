<html lang="en">
<head>

<!-- Latest compiled and minified Bootstrap Core CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<!-- Bootstrap theme -->
<link href="../../dist/css/bootstrap-theme.min.css" rel="stylesheet">

   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <title>Exercise 9-6 | Using the $_SERVER Array</title>
</head>
<body>
<header>
<h1>Demonstrating $_SERVER usage</h1>
</header>

<pre>
<?php
print_r($_SERVER);
?>
</pre>
</body>
</html>
