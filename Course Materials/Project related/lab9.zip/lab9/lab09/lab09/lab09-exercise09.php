<html lang="en">
<head>

<!-- Latest compiled and minified Bootstrap Core CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<!-- Bootstrap theme -->
<link href="../../dist/css/bootstrap-theme.min.css" rel="stylesheet">

   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <title>Exercise 9-7 | Processing file uploads</title>
</head>
<body>

<header>
<h1>File access in PHP</h1>
</header>

<div class='container'>
<?php 
//start by echoing the data in the file
$fileContents = file_get_contents("datafile.txt");
echo $fileContents;

?>
</div>


</body>
</html>
