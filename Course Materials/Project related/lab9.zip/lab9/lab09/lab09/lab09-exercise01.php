<html lang="en">
<head>

<!-- Latest compiled and minified Bootstrap Core CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<!-- Bootstrap theme -->
<link href="../../dist/css/bootstrap-theme.min.css" rel="stylesheet">

   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <title>Exercise 9-1 Weather Forecast</title>
</head>

<body>
<header>
</header>

 <div class="container theme-showcase" role="main">  
      <div class="jumbotron">
        <h1>Weather Forecast!</h1>
	<p>Coming soon...</p>
      </div>
       <div class="panel panel-default">
            <div class="panel-heading">
              <h3 class="panel-title">Monday</h3>
            </div>
            <div class="panel-body">
              <table class="table table-hover"><tbody>
		      <tr><td>High:</td><td>100&deg;??</td></tr>
	      	      <tr><td>Low:</td><td>100&deg;??</td></tr>
	      </tbody>	      </table>
            </div>
       </div>
 </div>
</body>
</html>