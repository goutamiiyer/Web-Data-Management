<html lang="en">
<head>

<!-- Latest compiled and minified Bootstrap Core CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<!-- Bootstrap theme -->
<link href="../../dist/css/bootstrap-theme.min.css" rel="stylesheet">

   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <title>Exercise 9-4 | Detecting a $_POST</title>
</head>

<body>
<header>
</header>


<?php

function getForm(){
   return "
<form action='' method='post'>
<input type='text' name='alias' />
<input type='submit' value='Post' />
</form>";
}
?>
 <div class="container theme-showcase" role="main">  
      <div class="jumbotron">
        <h1>No Post Detected....</h1>
      </div>
<?php echo getForm(); ?>
 </div>
</body>
</html>
