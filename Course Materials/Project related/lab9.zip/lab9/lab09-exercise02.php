<?php 
$forecast=array("Monday" =>array(20,10),"Tuesday" =>array(30,11),"Wednesday" =>array(26,15), "Thursday" =>array(30,10),"Friday" =>array(30,20),"Saturday" =>array(29,13),"Sunday" =>array(25,11));
// $lows=array("Monday" =>10, "Tuesday" =>11,"Wednesday" =>15, "Thursday" =>18,"Friday" =>20,"Saturday" =>13,"Sunday" =>11);
// $highs=array(20,30,26,30,30,29,25); $lows=array(10,11,15,18,20,13,11);

function outputForecast($day,$high,$low){
  echo '<div class="panel <div class="panel panel-default">';
  echo '<div class="panel-heading">'; echo '<h3 class="panel-title">'.$day.'</h3>';
  echo '</div>';echo '<div class="panel-body">';
  echo '<table class="table table-hover"><tbody>';
  echo '<tr><td>High:</td><td>'.$high.'</td></tr>';
  echo '<tr><td>Low:</td><td>'.$low.'</td></tr>';
  echo  '</tbody</table>'; echo '</div>';echo ' </div>'; } ?>
<html lang="en"> <head>
<!-- Latest compiled and minified Bootstrap Core CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<!-- Bootstrap theme -->
<link href="../../dist/css/bootstrap-theme.min.css" rel="stylesheet">
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <title>Exercise 9-1 Weather Forecast</title>
</head>
<body>
<header>
</header>
 <div class="container theme-showcase" role="main">  
 <div class="jumbotron"><h1>Weather Forecast!</h1> <p>Coming soon...</p> </div>
  <?php // version 2 
   foreach ($forecast as $key =>$weather) {
     outputForecast($key,$weather[0],$weather[1]); }
  ?>
 </div>
</body>
</html>